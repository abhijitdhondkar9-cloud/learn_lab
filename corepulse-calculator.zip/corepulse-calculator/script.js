const display = document.getElementById('display');
let current = '0';
let stored = null;
let op = null;

function show(value) {
  display.textContent = value;
}

document.querySelector('.keys').addEventListener('click', (e) => {
  const key = e.target.closest('button');
  if (!key) return;
  const { op: nextOp, action } = key.dataset;
  if (nextOp) return chooseOp(nextOp);
  if (action) return actions[action]();
  inputDigit(key.textContent);
});

function inputDigit(d) {
  if (d === '.' && current.includes('.')) return;
  current = current === '0' && d !== '.' ? d : current + d;
  show(current);
}

function chooseOp(next) {
  if (op) compute();
  stored = parseFloat(current);
  op = next;
  current = '0';
}

function compute() {
  const a = stored, b = parseFloat(current);
  const result = { '+': a + b, '-': a - b,
    '*': a * b, '/': b === 0 ? NaN : a / b }[op];
  current = Number.isFinite(result)
    ? String(+result.toFixed(10)) : 'Error';
  op = null;
  show(current);
}

const actions = {
  clear() { current = '0'; stored = op = null; show(current); },
  sign() { current = String(-current); show(current); },
  percent() { current = String(current / 100); show(current); },
  equals() { if (op) compute(); },
};
